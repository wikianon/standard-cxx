#ifndef PLUGINCTL_H
#define PLUGINCTL_H
void setup_plugin();
void close_plugin();

#endif
