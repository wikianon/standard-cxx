--
-- PostgreSQL database dump
--

-- Dumped from database version 8.4.14
-- Dumped by pg_dump version 9.1.4
-- Started on 2012-11-15 16:00:12

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = mne_application, pg_catalog;

INSERT INTO mne_application.menu (createdate, createuser, modifydate, modifyuser, menupos, parentid, menuid, menuname, action, itemname, ugroup, custom) VALUES (1313565156, 'manny', 1326127699, 'manny', 60, '47555fd90000', '4e4b69e40000', 'erp', 'show(''hoai_admin'')', 'HOIA', 'admincrm', false);

