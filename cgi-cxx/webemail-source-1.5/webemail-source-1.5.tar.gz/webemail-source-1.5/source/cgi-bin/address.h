#ifndef _address_h
#define _address_h

void address();
void add_single_addr(char *fill, int email); //-1 blank //-2 has email
void process_single();
void s_sendto_addr();
void edit_single_addr();
void reprocess_single();
void add_name_inbox();
void add_group_addr(int email);
void process_group();
void delete_addr();
void delete_group_addr();
void g_sendto_addr();
void edit_group_addr();
void reprocess_group();
#endif

