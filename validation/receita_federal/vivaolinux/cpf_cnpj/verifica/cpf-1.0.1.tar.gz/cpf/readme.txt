Programa Gerador de CPF v1.0 for Linux
--------------------------------------

Autor: Jefferson dos Santos Felix
Data: 20/10/2001

ATEN��O: ESTE PROGRAMA FOI DESENVOLVIDO SOB A GENERAL PUBLIC LICENSE (GPL).
LEIA O ARQUIVO GPL.TXT (EM INGLES) PARA MAIORES INFORMA��ES.

Conte�do do arquivo
-------------------
- cpf.cpp     C�digo-fonte do programa cpf.
- gpl.txt     General Public License (GPL).
- install.sh  Script de Instala��o do programa cpf.
- readme.txt  Este arquivo.

Instala��o
----------

- Descompacte o arquivo em um diret�rio qualquer (ex: /root),
utilizando o seguinte comando:
tar -zxvf cpf-1.0.1.tar.gz

- Entre no diret�rio criado, digitando:
cd cpf

- Digite o seguinte comando:
./install.sh

Pronto. O Programa Gerador de CPF foi compilado com sucesso. Caso tenha 
aparecido alguma mensagem de erro, certifique-se de que voc� possui instalado 
em sua m�quina as bibliotecas de desenvolvimento do C e a biblioteca ncurses.

Rodando o Programa
------------------

Para executar o programa, digite na linha de comando:
cpf

:)
Falow ae!

---------------------------
Jefferson dos Santos Felix
jeffersonsfelix@yahoo.com.br
