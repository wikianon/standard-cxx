#include <vector>

#ifndef _save_h
#define _save_h
void save_inbox();
void index_saved();
void read_saved();
void delete_saved();
void multi_del_saved();
void viewprint_saved();
void viewhtml_saved();
void u_attach_saved();
void m_attach_saved();
void reply_saved();
void forward_saved();
#endif


