sysok=( 16_04 )
mne_checksys