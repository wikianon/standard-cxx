#!/bin/bash

psql=/Library/PostgreSQL/9.3/bin/psql

apache2sitedir=/etc/apache2/other
apache2ensite=
apache2reload="apachectl restart"

netinterfaces=notavaible
