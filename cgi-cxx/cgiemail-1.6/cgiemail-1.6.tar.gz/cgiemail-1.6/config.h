/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you want to enable use of environment variables.  */
#define ENABLE_CGIENV 1

/* Define to attempt to send bounces to owner of template file.  */
/* #undef ENABLE_OWNER_BOUNCE */

/* Define if you want to enable the X-Mailer header.  */
#define ENABLE_XHEADERS 1

/* Define if you have the sigprocmask function.  */
#define HAVE_SIGPROCMASK 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the nsl library (-lnsl).  */
/* #undef HAVE_LIBNSL */

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */
