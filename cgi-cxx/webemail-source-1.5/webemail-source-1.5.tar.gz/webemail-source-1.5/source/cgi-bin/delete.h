#ifndef _delete_h
#define _delete_h



#endif


