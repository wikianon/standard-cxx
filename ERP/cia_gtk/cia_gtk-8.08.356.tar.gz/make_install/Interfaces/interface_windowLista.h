/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_windowLista_H
	#define _BEINTERFACES_windowLista_H

	GtkWidget *be_Interface_criar_windowLista (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_windowLista_table1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_scrolledwindow1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_treeviewLista (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_hbuttonbox1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_buttonOK (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_alignment22 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_hbox22 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_image574 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_label57 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_buttonCancelar (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_alignment23 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_hbox23 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_image575 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowLista_label58 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_windowLista_ajustes_finais (GtkWidget *janela);

#endif
