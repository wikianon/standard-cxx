/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_windowAutenticar_H
	#define _BEINTERFACES_windowAutenticar_H

	GtkWidget *be_Interface_criar_windowAutenticar (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_windowAutenticar_table5 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label5 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label6 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_image17 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_entryIdentidade (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_entrySenha (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_hbuttonbox3 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_buttonOK (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_alignment28 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_hbox28 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_image580 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label63 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_buttonCancelar (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_alignment29 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_hbox29 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_image581 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label64 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_hseparator1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_frameAlterarSenha (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_alignment4 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_table6 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_image19 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label13 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_entryNova (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_entryConfirma (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label14 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowAutenticar_label12 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_windowAutenticar_ajustes_finais (GtkWidget *janela);

#endif
