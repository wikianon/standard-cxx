DBUSER=mneerpsystem
DB=erpdb

IMPL=mneerp

