/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_fontselectiondialogFonte_H
	#define _BEINTERFACES_fontselectiondialogFonte_H

	GtkWidget *be_Interface_criar_fontselectiondialogFonte (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_fontselectiondialogFonte_cancel_button2 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_fontselectiondialogFonte_apply_button1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_fontselectiondialogFonte_ok_button2 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_fontselectiondialogFonte_font_selection1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_fontselectiondialogFonte_ajustes_finais (GtkWidget *janela);

#endif
