#ifndef hashes_mne
#define hashes_mne

#include <string>

std::string digests_base64(char *name, const char *in);

#endif /* hashes_mne */
