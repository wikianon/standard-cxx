#include <vector>

#ifndef _inbox_h
#define _inbox_h
void index_inbox();
void read_inbox();
void delete_inbox();
void multi_del_inbox();
//void showinboxattach();
void viewprint_inbox();
void viewhtml_inbox();
void u_attach_inbox();
void m_attach_inbox();
void reply_inbox();
void forward_inbox();
#endif


