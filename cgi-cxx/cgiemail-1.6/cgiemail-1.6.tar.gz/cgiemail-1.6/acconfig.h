/* Define if you want to enable use of environment variables.  */
#undef ENABLE_CGIENV

/* Define to attempt to send bounces to owner of template file.  */
#undef ENABLE_OWNER_BOUNCE

/* Define if you want to enable the X-Mailer header.  */
#undef ENABLE_XHEADERS
