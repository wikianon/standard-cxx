/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_windowPropriedades_H
	#define _BEINTERFACES_windowPropriedades_H

	GtkWidget *be_Interface_criar_windowPropriedades (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_windowPropriedades_table4 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_scrolledwindow5 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_viewportFundo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_tableFundo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelNumero (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelFonte (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelCor (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelArquivo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelDiretorio (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelLista (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryNumero (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryFonte (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryCor (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryArquivo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryDiretorio (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonFonte (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image16 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonCor (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image12 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonArquivo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image13 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonDiretorio (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image14 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryLista (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonLista (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image464 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_entryPropriedades (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelPropriedades (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labellogico (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_checkbuttonLogico (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelRotulo (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_labelInformacao (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_hbuttonbox2 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonOK (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_alignment26 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_hbox26 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image578 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_label61 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_buttonCancelar (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_alignment27 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_hbox27 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_image579 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_windowPropriedades_label62 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_windowPropriedades_ajustes_finais (GtkWidget *janela);

#endif
