/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_windowZoom_H
	#define _BEINTERFACES_windowZoom_H

	GtkWidget *be_Interface_criar_windowZoom (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_windowZoom_imageZoom (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_windowZoom_ajustes_finais (GtkWidget *janela);

#endif
