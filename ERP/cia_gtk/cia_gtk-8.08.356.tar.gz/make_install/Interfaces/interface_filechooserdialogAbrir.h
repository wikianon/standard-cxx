/*
+------------------------------------------------------------------------------+
| ARQUIVO GERADO AUTOMATICAMENTE POR be_Interfaces                             |
+------------------------------------------------------------------------------+
*/
#ifndef _BEINTERFACES_filechooserdialogAbrir_H
	#define _BEINTERFACES_filechooserdialogAbrir_H

	GtkWidget *be_Interface_criar_filechooserdialogAbrir (GtkWindow *winpai, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data);
	GtkWidget *be_Interface_criar_filechooserdialogAbrir_dialog_vbox1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_filechooserdialogAbrir_dialog_action_area1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_filechooserdialogAbrir_button1 (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	GtkWidget *be_Interface_criar_filechooserdialogAbrir_buttonOK (GtkWidget *janela, GtkAccelGroup *accel, GtkTooltips *tip, gpointer Data, GtkWidget *mae);
	void _be_Interfaces_filechooserdialogAbrir_ajustes_finais (GtkWidget *janela);

#endif
