sysok=( 12_04 14_04 16_04 )
mne_checksys