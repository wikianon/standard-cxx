DBUSER=mneerpsystem
DB=erpdb

IMPL=mneerp
DATAROOT=/home/manny/projects/data
