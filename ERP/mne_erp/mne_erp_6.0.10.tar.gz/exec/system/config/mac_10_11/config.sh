#!/bin/bash

psql=/Library/PostgreSQL/9.5/bin/psql

apache2sitedir=/opt/local/apache2/conf/other
apache2ensite=
apache2reload="/opt/local/apache2/bin/apachectl restart"

netinterfaces=notavaible
