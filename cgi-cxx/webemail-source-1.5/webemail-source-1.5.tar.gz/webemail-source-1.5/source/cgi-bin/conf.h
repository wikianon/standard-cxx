#define HAS_SHADOW

