sysok=( 12_04 14_04 16_04 mac_10_8 )
mne_checksys