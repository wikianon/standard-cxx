#include <vector>

#ifndef _sent_h
#define _sent_h
void index_sent();
void read_sent();
void delete_sent();
void multi_del_sent();
void viewprint_sent();
void viewhtml_sent();
void u_attach_sent();
void m_attach_sent();
#endif


